# Test package initialization
